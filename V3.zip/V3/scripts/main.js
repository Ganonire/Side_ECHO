// ================================================================
// SIDE ECHO — main.js
// Оптимизированная версия с подробными комментариями.
// Включает: плавный переход, магазин, сдвиг UI энергии при смене 
// комнаты и закрытие списка по крестику.
// ================================================================

runOnStartup(runtime => {
    runtime.addEventListener("beforeprojectstart", () => {
        // Защита от повторной инициализации (от дублей скрипта).
        if (window.__energyInitDone) return;
        window.__energyInitDone = true;

        // ------------------------------------------------------------
        // Помощники: если объекта нет в проекте, ничего не падает.
        // ------------------------------------------------------------
        const getOne = (name) => runtime.objects[name]?.getFirstInstance() ?? null;
        const getAll = (name) => runtime.objects[name]?.getAllInstances() ?? [];

        // ------------------------------------------------------------
        // Объекты прототипа.
        // ------------------------------------------------------------
        const varManager = runtime.objects.varManager.getFirstInstance();
        const energyText = runtime.objects.energyText.getFirstInstance();
        const energyBar = runtime.objects.energyBar.getFirstInstance();
        const energyBarBG = getOne("energyBarBG");
        
        // Собираем кнопки энергии в массив и отсеиваем null
        const energyButtons = [
            getOne("energyButton"), 
            getOne("energyButton2"), 
            getOne("energyButton3")
        ].filter(Boolean);

        const changeFrameButton = getOne("changeFrameButton");
        const cameraObj = runtime.objects.cameraObj.getFirstInstance();
        const audioObj = getOne("Audio");
        const coffeeButton = getOne("coffeeButton");
        const blackBlock = getOne("blackBlock");

        // Сегменты шкалы энергии слева направо.
        const energySegments = getAll("energySegment").sort((a, b) => a.x - b.x);

        // Позиции камер для комнат и полное значение энергии.
        const ROOM1_X = 935;
        const ROOM2_X = 2905;
        const MAX_ENERGY = 15;
        let lastDisplayedEnergy = NaN;

        // ============================================================
        // НАСТРОЙКИ МАГАЗИНА И ВАЛЮТЫ
        // ============================================================
        const CURRENCY_LABEL = "ТАЛОНЫ";
        const COFFEE_PRICE = 3;
        const COFFEE_RESTORE = MAX_ENERGY;
        const CATFOOD_PRICE = 2;
        const CATFOOD_MAX = 5;

        // ============================================================
        // ЗВУК (с защитой от параллельных загрузок)
        // ============================================================
        const MUSIC_TRACK = "music/8597bb02c2b2555.webm";
        const SFX_CLICK = "sounds/off-button-on-table-lamp.webm";
        const SFX_BUY = SFX_CLICK;
        const SFX_DENY = SFX_CLICK;
        const MUSIC_VOLUME = 0.4;
        const SFX_VOLUME = 0.8;

        const audioCtx = audioObj ? audioObj.audioContext : null;
        const audioBuffers = {};
        const loadingPromises = {}; // Защита от дублей загрузки

        async function loadBuffer(filename) {
            if (audioBuffers[filename]) return audioBuffers[filename];
            if (loadingPromises[filename]) return loadingPromises[filename];

            loadingPromises[filename] = (async () => {
                const url = await runtime.assets.getProjectFileUrl(filename);
                const response = await fetch(url);
                const arrayBuffer = await response.arrayBuffer();
                const buffer = await audioCtx.decodeAudioData(arrayBuffer);
                audioBuffers[filename] = buffer;
                delete loadingPromises[filename];
                return buffer;
            })();
            return loadingPromises[filename];
        }

        async function playSound(filename, { loop = false, vol = 1 } = {}) {
            if (!audioObj || !audioCtx) return;
            try {
                const buffer = await loadBuffer(filename);
                if (audioCtx.state === "suspended") {
                    await audioCtx.resume();
                }
                const source = audioCtx.createBufferSource();
                source.buffer = buffer;
                source.loop = loop;
                const gain = audioCtx.createGain();
                gain.gain.value = vol;
                source.connect(gain);
                gain.connect(audioObj.destinationNode);
                source.start();
            } catch (err) {
                console.error("Ошибка воспроизведения звука:", filename, err);
            }
        }

        let musicStarted = false;
        function startMusicIfFirstClick() {
            if (musicStarted) return;
            musicStarted = true;
            playSound(MUSIC_TRACK, { loop: true, vol: MUSIC_VOLUME });
        }

        const playClickSfx = () => playSound(SFX_CLICK, { vol: SFX_VOLUME });
        const playBuySfx = () => playSound(SFX_BUY, { vol: SFX_VOLUME });
        const playDenySfx = () => playSound(SFX_DENY, { vol: SFX_VOLUME });

        // ============================================================
        // ВАЛЮТА.
        // ============================================================
        const getCredits = () => varManager.instVars.Credits;
        const getCatFood = () => varManager.instVars.CatFood;

        function addCredits(amount) {
            varManager.instVars.Credits = Math.max(0, getCredits() + amount);
            updateCreditsUI();
        }

        function spendCredits(amount) {
            if (getCredits() < amount) return false;
            varManager.instVars.Credits = getCredits() - amount;
            updateCreditsUI();
            return true;
        }

        const creditsTexts = getAll("creditsText").concat(getAll("shopCreditsText"));
        const creditsBaseColor = new Map();
        creditsTexts.forEach(t => creditsBaseColor.set(t, [...t.colorRgb]));

        let lastDisplayedCredits = NaN;
        let creditsFlashTimer = null;

        function updateCreditsUI() {
            const credits = getCredits();
            if (credits === lastDisplayedCredits) return;

            const previous = lastDisplayedCredits;
            lastDisplayedCredits = credits;

            const label = `${CURRENCY_LABEL}: ${credits}`;
            creditsTexts.forEach(t => { 
                if (t.text !== label) t.text = label; 
            });

            if (!Number.isNaN(previous)) {
                const flash = credits > previous ? [0.4, 1, 0.5] : [1, 0.4, 0.4];
                creditsTexts.forEach(t => { t.colorRgb = flash; });
                clearTimeout(creditsFlashTimer);
                creditsFlashTimer = setTimeout(() => {
                    creditsTexts.forEach(t => { t.colorRgb = creditsBaseColor.get(t); });
                }, 400);
            }
        }

        // ============================================================
        // ЭНЕРГИЯ.
        // ============================================================
        function updateEnergyUI() {
            const energy = varManager.instVars.Energy;
            const energyString = String(energy);

            if (energyText.text !== energyString) {
                energyText.text = energyString;
            }

            if (energy === lastDisplayedEnergy) return;
            lastDisplayedEnergy = energy;

            const ratio = Math.max(0, Math.min(1, energy / MAX_ENERGY));

            if (energySegments.length > 0) {
                const litCount = Math.round(ratio * energySegments.length);
                energySegments.forEach((segment, index) => {
                    segment.isVisible = index < litCount;
                });
                energyBar.isVisible = false;
                if (energyBarBG) energyBarBG.isVisible = true;
            } else {
                energyBar.isVisible = ratio > 0;
            }
        }

        // ============================================================
        // ПЕРЕХОД (Затемнение через blackBlock)
        // ============================================================
        const FADE_SPEED = 2.5; // Скорость перехода
        let panPhase = "idle";
        let pendingRoomSelect = false;

        function isTransitioning() {
            return panPhase !== "idle";
        }

        if (blackBlock) {
            blackBlock.opacity = 0;
            blackBlock.isVisible = true;
        }

        // ============================================================
        // МАГАЗИН.
        // ============================================================
        const shopButton = getOne("shopButton");
        const shopCloseButton = getOne("shopCloseButton");
        const shopCoffeeBuyButton = getOne("shopCoffeeBuyButton");
        const shopCatFoodBuyButton = getOne("shopCatFoodBuyButton");
        const shopCoffeeText = getOne("shopCoffeeText");
        const shopCatFoodText = getOne("shopCatFoodText");
        const shopMessageText = getOne("shopMessageText");

        const SHOP_PART_NAMES = [
            "shopPanel", "shopTitleText", "shopCreditsText", "shopMessageText",
            "shopCoffeeText", "shopCatFoodText",
            "shopCloseButton", "shopCoffeeBuyButton", "shopCatFoodBuyButton"
        ];
        const shopParts = SHOP_PART_NAMES.flatMap(getAll);
        const coveredButtons = [...energyButtons, changeFrameButton].filter(Boolean);

        let shopOpen = false;
        let coffeeInStock = false;
        let messageTimer = null;

        function showShopMessage(text) {
            if (!shopMessageText) return;
            shopMessageText.text = text;
            clearTimeout(messageTimer);
            messageTimer = setTimeout(() => { shopMessageText.text = ""; }, 1800);
        }

        function refreshShopTexts() {
            if (shopCoffeeText) {
                shopCoffeeText.text =
                    `Кофе (цена: ${COFFEE_PRICE})${coffeeInStock ? " — куплен" : ""}\n` +
                    `Восстанавливает энергию`;
            }
            if (shopCatFoodText) {
                shopCatFoodText.text =
                    `Кошачий корм (цена: ${CATFOOD_PRICE})\n` +
                    `Запас: ${getCatFood()}/${CATFOOD_MAX}`;
            }
        }

        function openShop() {
            if (shopOpen) return;
            if (isTransitioning()) return;
            shopOpen = true;

            coveredButtons.forEach(b => { b.isVisible = false; });
            if (coffeeButton) coffeeButton.isVisible = false;

            shopParts.forEach(p => { p.isVisible = true; });
            if (shopMessageText) shopMessageText.text = "";
            refreshShopTexts();
        }

        function closeShop() {
            if (!shopOpen) return;
            shopOpen = false;

            shopParts.forEach(p => { p.isVisible = false; });
            coveredButtons.forEach(b => { b.isVisible = true; });
            
            if (coffeeButton) coffeeButton.isVisible = coffeeInStock;
        }

        function buyCoffee() {
            if (coffeeInStock) {
                showShopMessage("Кофе уже куплен");
                playDenySfx();
                return;
            }
            if (!spendCredits(COFFEE_PRICE)) {
                showShopMessage("Не хватает талонов");
                playDenySfx();
                return;
            }
            coffeeInStock = true;
            showShopMessage("Кофе куплен — он на второй панели");
            playBuySfx();
            refreshShopTexts();
        }

        function buyCatFood() {
            if (getCatFood() >= CATFOOD_MAX) {
                showShopMessage("Запас корма полон");
                playDenySfx();
                return;
            }
            if (!spendCredits(CATFOOD_PRICE)) {
                showShopMessage("Не хватает талонов");
                playDenySfx();
                return;
            }
            varManager.instVars.CatFood = getCatFood() + 1;
            showShopMessage("Корм куплен");
            playBuySfx();
            refreshShopTexts();
        }

        // ============================================================
        // ОБЪЕДИНЁННЫЙ tick2: переходы + UI.
        // ============================================================
        runtime.addEventListener("tick2", () => {
            // 1. Логика перехода
            if (panPhase !== "idle" && blackBlock) {
                if (panPhase === "fadeOut") {
                    blackBlock.opacity = Math.min(1, blackBlock.opacity + FADE_SPEED * runtime.dt);

                    if (blackBlock.opacity >= 1) {
                        // Экран полностью чёрный — переключаем комнату и телепортируем камеру.
                        varManager.instVars.roomSelect = pendingRoomSelect;
                        
                        // --- НОВОЕ: Сдвиг шкалы энергии вместе с камерой ---
                        const shift = pendingRoomSelect ? (ROOM2_X - ROOM1_X) : (ROOM1_X - ROOM2_X);
                        cameraObj.x = pendingRoomSelect ? ROOM2_X : ROOM1_X;
                        
                        energyText.x += shift;
                        energyBar.x += shift;
                        if (energyBarBG) energyBarBG.x += shift;
                        energySegments.forEach(seg => seg.x += shift);
                        // --------------------------------------------------
                        
                        panPhase = "fadeIn";
                    }
                } else if (panPhase === "fadeIn") {
                    blackBlock.opacity = Math.max(0, blackBlock.opacity - FADE_SPEED * runtime.dt);
                    if (blackBlock.opacity <= 0) {
                        panPhase = "idle";
                    }
                }
            }

            // 2. Обновление UI (только если значения реально изменились)
            const currentEnergy = varManager.instVars.Energy;
            if (currentEnergy !== lastDisplayedEnergy) updateEnergyUI();
            
            const currentCredits = varManager.instVars.Credits;
            if (currentCredits !== lastDisplayedCredits) updateCreditsUI();
        });

        // ============================================================
        // Обработчики кнопок магазина.
        // ============================================================
        if (shopButton) {
            shopButton.isVisible = true;
            shopButton.addEventListener("click", () => {
                openShop();
                startMusicIfFirstClick();
                playClickSfx();
            });
        }
        if (shopCloseButton) {
            shopCloseButton.addEventListener("click", () => {
                closeShop();
                startMusicIfFirstClick();
                playClickSfx();
            });
        }
        if (shopCoffeeBuyButton) {
            shopCoffeeBuyButton.addEventListener("click", () => {
                buyCoffee();
                startMusicIfFirstClick();
            });
        }
        if (shopCatFoodBuyButton) {
            shopCatFoodBuyButton.addEventListener("click", () => {
                buyCatFood();
                startMusicIfFirstClick();
            });
        }

        runtime.addEventListener("keydown", (e) => {
            if (e.key === "Escape") closeShop();
        });

        shopParts.forEach(p => { p.isVisible = false; });

        // ============================================================
        // Кнопка кофе: выпить купленный кофе.
        // ============================================================
        if (coffeeButton) {
            coffeeButton.isVisible = false;
            coffeeButton.addEventListener("click", () => {
                if (shopOpen || isTransitioning() || !coffeeInStock) return;
                coffeeInStock = false;

                varManager.instVars.Energy = Math.min(
                    MAX_ENERGY,
                    varManager.instVars.Energy + COFFEE_RESTORE
                );
                updateEnergyUI();
                startMusicIfFirstClick();
                playClickSfx();
                coffeeButton.isVisible = false;
            });
        }

        // ============================================================
        // Кнопки расхода энергии.
        // ============================================================
        energyButtons.forEach(button => {
            button.addEventListener("click", () => {
                if (shopOpen || isTransitioning()) return;
                varManager.instVars.Energy = Math.max(0, varManager.instVars.Energy - 1);
                updateEnergyUI();
                startMusicIfFirstClick();
                playClickSfx();
            });
        });

        // ============================================================
        // Переключение комнат.
        // ============================================================
        if (changeFrameButton) {
            changeFrameButton.addEventListener("click", () => {
                if (shopOpen || isTransitioning()) return;

                startMusicIfFirstClick();
                playClickSfx();

                if (blackBlock) {
                    pendingRoomSelect = !varManager.instVars.roomSelect;
                    panPhase = "fadeOut";
                } else {
                    // Запасной вариант (мгновенный прыжок), если нет blackBlock.
                    varManager.instVars.roomSelect = !varManager.instVars.roomSelect;
                    
                    // Сдвигаем камеру и UI
                    const shift = varManager.instVars.roomSelect ? (ROOM2_X - ROOM1_X) : (ROOM1_X - ROOM2_X);
                    cameraObj.x = varManager.instVars.roomSelect ? ROOM2_X : ROOM1_X;
                    
                    energyText.x += shift;
                    energyBar.x += shift;
                    if (energyBarBG) energyBarBG.x += shift;
                    energySegments.forEach(seg => seg.x += shift);
                }
            });
        }

        // ============================================================
        // Список-чеклист (С добавленным крестиком).
        // ============================================================
        const listButton = runtime.objects.listButton.getFirstInstance();
        const listPanel = runtime.objects.listPanel.getFirstInstance();
        
        // НОВОЕ: Объявляем крестик и элементы списка
        const listCloseButton = getOne("listCloseButton");
        const listItems = [
            runtime.objects.listItem1.getFirstInstance(),
            runtime.objects.listItem2.getFirstInstance(),
            runtime.objects.listItem3.getFirstInstance()
        ].filter(Boolean);

        listPanel.isVisible = false;
        if (listCloseButton) listCloseButton.isVisible = false; // Скрываем крестик при старте
        listItems.forEach(item => { item.isVisible = false; });

        function isPointerOver(instance, clientX, clientY) {
            if (!instance) return false;
            const [lx, ly] = instance.layer.cssPxToLayer(clientX, clientY);
            const left = instance.x - instance.width * instance.originX;
            const right = instance.x + instance.width * (1 - instance.originX);
            const top = instance.y - instance.height * instance.originY;
            const bottom = instance.y + instance.height * (1 - instance.originY);
            return lx >= left && lx <= right && ly >= top && ly <= bottom;
        }

        function toggleList() {
            const expanded = !listPanel.isVisible;
            listPanel.isVisible = expanded;
            if (listCloseButton) listCloseButton.isVisible = expanded; // Показываем крестик
            listItems.forEach(item => { item.isVisible = expanded; });
        }

        runtime.addEventListener("pointerdown", (e) => {
            if (shopOpen || isTransitioning()) return;

            if (isPointerOver(listButton, e.clientX, e.clientY)) {
                toggleList();
                startMusicIfFirstClick();
                playClickSfx();
                return;
            }

            if (!listPanel.isVisible) return;

            // НОВОЕ: Проверка клика по крестику для закрытия
            if (isPointerOver(listCloseButton, e.clientX, e.clientY)) {
                toggleList();
                startMusicIfFirstClick();
                playClickSfx();
                return; // Выходим, чтобы не проверять галочки
            }

            // Проверка кликов по галочкам
            listItems.forEach((item) => {
                if (isPointerOver(item, e.clientX, e.clientY)) {
                    item.animationFrame = item.animationFrame === 0 ? 1 : 0;
                    startMusicIfFirstClick();
                    playClickSfx();
                }
            });
        });

        // ============================================================
        // Запуск и обновление интерфейса.
        // ============================================================
        updateEnergyUI();
        updateCreditsUI();
        refreshShopTexts();

        window.sideEcho = { addCredits, spendCredits, openShop, closeShop };
    });
});